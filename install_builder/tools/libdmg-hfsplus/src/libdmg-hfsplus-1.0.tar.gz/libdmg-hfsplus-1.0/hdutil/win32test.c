#include <stdlib.h>

#ifdef WIN32
blahfs-o_f-0-(){ {}A
#else
int main(int argc, char* argv[]) {
  return 0;
}
#endif
